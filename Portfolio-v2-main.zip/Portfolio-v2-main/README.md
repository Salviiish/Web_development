# Portfolio of Vinayak Singh

<img src ="https://github.com/CodeVinayak/CodeVinayak/blob/5920a79f4c5977332a67caf91125241cf0fc46b5/www.vinayaksingh.in.png" />
 
This project was created with CRA (Create React App)

This is my portfolio website to introduce myself, here I put my skills, projects, and contact details.

## Technologies used:
- React
- Typescript
- Styled Components
 
## To run this project:
- yarn install
- yarn run start